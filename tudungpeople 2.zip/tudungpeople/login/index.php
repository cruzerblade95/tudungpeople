<?php
include "include/dbconnect.php";
session_start();
if(isset($_POST['login'])){
$username = $_POST['username'];


$query = "select username,password from login where username='$username'";
$result = mysqli_query($db,$query);

if($result){
  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
  if(!empty($row['username'])){
    $_SESSION[username]="$row[username]";
    $_SESSION[password]="$row[password]";
  echo '<meta http-equiv="refresh" content="0; url=puzzle.php">';
}else{
  ?>
  <script>alert("Your Username is incorrect or not registered");</script>
<?php
}
}else{
  ?>
  <script>alert("Your Username is incorrect or not registered");</script>
<?php
}
}

?>
<head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="include/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/util.css">
	<link rel="stylesheet" type="text/css" href="include/css/main.css">
<!--===============================================================================================-->
</head>

<body>


<div class="limiter">
  <div class="container-login100">
    <div class="wrap-login100">
      <div class="login100-pic js-tilt" data-tilt>
        <img src="include/images/img-01.png" alt="IMG">
      </div>

      <form class="login100-form validate-form" action="index.php" method="post" class="form">
        <span class="login100-form-title">
          Login
        </span>

        <div class="wrap-input100 validate-input">
          <input class="input100" type="text" name="username" placeholder="Username" required>
          <span class="focus-input100"></span>
          <span class="symbol-input100">
            <i class="fa fa-envelope" aria-hidden="true"></i>
          </span>
        </div>


        <div class="container-login100-form-btn">
          <input type="submit" class="login100-form-btn" name="login" value="Login">
        </div>



        <div class="text-center p-t-136">
          <a class="txt2" data-toggle="modal" href="#myModal">
            Create your Account
            <i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
          </a>
        </div>
      </form>
    </div>
  </div>
</div>
<br/>
<!-- Modal Create Account -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Register</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">


        <form action="register.php" method="post" class="login100-form">

          <label for="username-form">First Name</label>
          <div class="wrap-input100">
          <input class="input100" id="username-form" type="text" name="fname" placeholder="First Name" required>
          <span class="focus-input100"></span>
          </div>

        <label for="username-form">Last Name</label>
        <div class="wrap-input100">
        <input class="input100" id="username-form" type="text" name="lname" placeholder="Last Name" required>
        <span class="focus-input100"></span>
        </div>

        <label for="username-form">Username</label>
        <div class="wrap-input100">
        <input class="input100" id="username-form" type="text" name="username" placeholder="Username" required>
        <span class="focus-input100"></span>
        </div>

        <label for="username-form">Phone</label>
        <div class="wrap-input100">
        <input class="input100" id="username-form" type="text" name="phone" placeholder="Phone" required>
        <span class="focus-input100"></span>
        </div>

        <label for="username-form">Address</label>
        <div class="wrap-input100">
        <textarea name="address" class="input100" maxlength="300" placeholder="Address" required></textarea>
        <span class="focus-input100"></span>
        </div>

        <label for="username-form">Email</label>
        <div class="wrap-input100">
        <input class="input100" id="username-form" type="email" name="email" placeholder="Email" required>
        <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100">
        <legend>Password</legend>
        <input class="input100" id="password-form" type="password" name="password1" placeholder="Password" minlength="4" required>
        </div>
        <div class="wrap-input100">
        <input class="input100" id="password-form" type="password" name="password2" placeholder="Re-enter Password" minlength="4" required>
        </div>

        <div class="wrap-input100">
        <legend>Input</legend>
        <center>
          <table border="1">
            <tr>
              <td></td>
              <td><input type="radio" name="movement" value="up"></td>
              <td></td>
            </tr>
            <tr>
              <td><input type="radio" name="movement" value="left"></td>
              <td></td>
              <td><input type="radio" name="movement" value="right"></td>
            </tr>
            <tr>
              <td></td>
              <td><input type="radio" name="movement" value="down"></td>
              <td></td>
            </tr>
          </table>
        </center>
        </div>


        <p><input type="submit" class="btn btn-primary" name="submit" value="Register"></p>
</form>
      </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
<?php
include("register.php");
?>

<!--===============================================================================================-->
<script src="include/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="include/vendor/bootstrap/js/popper.js"></script>
<script src="include/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="include/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="include/vendor/tilt/tilt.jquery.min.js"></script>
<script >
  $('.js-tilt').tilt({
    scale: 1.1
  })
</script>
<!--===============================================================================================-->
<script src="include/js/main.js"></script>
</body>
