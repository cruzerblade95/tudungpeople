

<?php
session_start();
include "include/dbconnect.php";

if(!isset($_POST['continue'])){
  $_SESSION['count'] = 1;
}

$username = $_SESSION['username'];
$password = $_SESSION['password'];

$alpha = "abcdefghijklmnopqrstuvwxyz";
$arrayalpha = str_split($alpha);

$query = "select keyword,movement,input from login where username='$username' and password='$password'";
$result = mysqli_query($db,$query);

if($result){
  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
  $delete_alpha = str_split($row['keyword']);
  $uniq = str_split($row['input']);
  $movement = $row['movement'];


  if (($key = array_search($delete_alpha[0], $arrayalpha)) !== false) {
    unset($arrayalpha[$key]);
}
if (($key = array_search($delete_alpha[1], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
if (($key = array_search($delete_alpha[2], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
if (($key = array_search($delete_alpha[3], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}

$alpha = implode($arrayalpha,"");
$countstr = strlen($alpha);
$arrayalpha = str_split($alpha);

if($countstr == 22){
$keys = array_rand($arrayalpha,1);
if (($key = array_search($arrayalpha[$keys[0]], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
$alpha = implode($arrayalpha,"");

}else if($countstr == 23){
$keys = array_rand($arrayalpha,2);
if (($key = array_search($arrayalpha[$keys[0]], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
if (($key = array_search($arrayalpha[$keys[1]], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
$alpha = implode($arrayalpha,"");

}else if($countstr == 24){
$keys = array_rand($arrayalpha,3);
if (($key = array_search($arrayalpha[$keys[0]], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
if (($key = array_search($arrayalpha[$keys[1]], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
if (($key = array_search($arrayalpha[$keys[2]], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
$alpha = implode($arrayalpha,"");

}else if($countstr == 25){
$keys = array_rand($arrayalpha,4);
if (($key = array_search($arrayalpha[$keys[0]], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
if (($key = array_search($arrayalpha[$keys[1]], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
if (($key = array_search($arrayalpha[$keys[2]], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
if (($key = array_search($arrayalpha[$keys[3]], $arrayalpha)) !== false) {
  unset($arrayalpha[$key]);
}
$alpha = implode($arrayalpha,"");

}


$usealpha = implode($delete_alpha,"");
$setalpha = $usealpha . $alpha;

$countstr1 = strlen($setalpha);

if($countstr1 == 26){
$setalpha = substr($setalpha, 0, -1);
}else if($countstr1 == 27){
$setalpha = substr($setalpha, 0, -2);
}else if($countstr1 == 28){
$setalpha = substr($setalpha, 0, -3);
}else if($countstr1 == 29){
$setalpha = substr($setalpha, 0, -4);
}else if($countstr1 == 30){
$setalpha = substr($setalpha, 0, -5);
}

$buttonalpha = str_split($setalpha);
$keyss = array_rand($buttonalpha,25);
$number = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25];
$keysss = array_rand($number,25);
shuffle($keysss);

echo "$setalpha";
$length = 25;
$alphause = implode($buttonalpha,"");
$randomletter = substr(str_shuffle($alphause), 0, $length);

$buttonalpha = str_split($randomletter);
$buttons1 = $buttonalpha[0];
$buttons2 = $buttonalpha[1];
$buttons3 = $buttonalpha[2];
$buttons4 = $buttonalpha[3];
$buttons5 = $buttonalpha[4];
$buttons6 = $buttonalpha[5];
$buttons7 = $buttonalpha[6];
$buttons8 = $buttonalpha[7];
$buttons9 = $buttonalpha[8];
$buttons10 = $buttonalpha[9];
$buttons11 = $buttonalpha[10];
$buttons12 = $buttonalpha[11];
$buttons13 = $buttonalpha[12];
$buttons14 = $buttonalpha[13];
$buttons15 = $buttonalpha[14];
$buttons16 = $buttonalpha[15];
$buttons17 = $buttonalpha[16];
$buttons18 = $buttonalpha[17];
$buttons19 = $buttonalpha[18];
$buttons20 = $buttonalpha[19];
$buttons21 = $buttonalpha[20];
$buttons22 = $buttonalpha[21];
$buttons23 = $buttonalpha[22];
$buttons24 = $buttonalpha[23];
$buttons25 = $buttonalpha[24];


//susunan puzzle
if($buttons1 == $delete_alpha[0]){
  if($movement == "up"){//done
    $button5 = $uniq[0];
  }else if($movement == "down"){//done
    $button2 = $uniq[0];
  }else if($movement == "left"){//done
    $button21 = $uniq[0];
  }else if($movement == "right"){//done
    $button6 = $uniq[0];
  }
}else if($buttons2 == $delete_alpha[0]){
  if($movement == "up"){//done
    $button1 = $uniq[0];
  }else if($movement == "down"){//done
    $button3 = $uniq[0];
  }else if($movement == "left"){//done
    $button22 = $uniq[0];
  }else if($movement == "right"){//done
    $button7 = $uniq[0];
  }}else if($buttons3 == $delete_alpha[0]){
    if($movement == "up"){//done
      $button2 = $uniq[0];
    }else if($movement == "down"){//done
      $button4 = $uniq[0];
    }else if($movement == "left"){//done
      $button23 = $uniq[0];
    }else if($movement == "right"){//done
      $button8 = $uniq[0];
    }}else if($buttons4 == $delete_alpha[0]){
      if($movement == "up"){
        $button3 = $uniq[0];
      }else if($movement == "down"){
        $button5 = $uniq[0];
      }else if($movement == "left"){
        $button24 = $uniq[0];
      }else if($movement == "right"){
        $button9 = $uniq[0];
      }}else if($buttons5 == $delete_alpha[0]){
        if($movement == "up"){
          $button4 = $uniq[0];
        }else if($movement == "down"){
          $button1 = $uniq[0];
        }else if($movement == "left"){
          $button25 = $uniq[0];
        }else if($movement == "right"){
          $button10 = $uniq[0];
        }}else if($buttons6 == $delete_alpha[0]){
          if($movement == "up"){//done
            $button10 = $uniq[0];
          }else if($movement == "down"){//done
            $button7 = $uniq[0];
          }else if($movement == "left"){//done
            $button1 = $uniq[0];
          }else if($movement == "right"){//done
            $button11 = $uniq[0];
          }}else if($buttons7 == $delete_alpha[0]){
          if($movement == "up"){//done
            $button6 = $uniq[0];
          }else if($movement == "down"){//done
            $button8 = $uniq[0];
          }else if($movement == "left"){//done
            $button2 = $uniq[0];
          }else if($movement == "right"){//done
            $button12 = $uniq[0];
          }}else if($buttons8 == $delete_alpha[0]){
            if($movement == "up"){//done
              $button7 = $uniq[0];
            }else if($movement == "down"){//done
              $button9 = $uniq[0];
            }else if($movement == "left"){//done
              $button3 = $uniq[0];
            }else if($movement == "right"){//done
              $button13 = $uniq[0];
            }}else if($buttons9 == $delete_alpha[0]){
              if($movement == "up"){
                $button8 = $uniq[0];
              }else if($movement == "down"){
                $button10 = $uniq[0];
              }else if($movement == "left"){
                $button4 = $uniq[0];
              }else if($movement == "right"){
                $button14 = $uniq[0];
              }}else if($buttons10 == $delete_alpha[0]){
                if($movement == "up"){
                  $button9 = $uniq[0];
                }else if($movement == "down"){
                  $button6 = $uniq[0];
                }else if($movement == "left"){
                  $button5 = $uniq[0];
                }else if($movement == "right"){
                  $button15 = $uniq[0];
                }
              }else if($buttons11 == $delete_alpha[0]){
                  if($movement == "up"){//done
                    $button15 = $uniq[0];
                  }else if($movement == "down"){//done
                    $button12 = $uniq[0];
                  }else if($movement == "left"){//done
                    $button6 = $uniq[0];
                  }else if($movement == "right"){//done
                    $button16 = $uniq[0];
                  }}else if($buttons12 == $delete_alpha[0]){
                  if($movement == "up"){//done
                    $button11 = $uniq[0];
                  }else if($movement == "down"){//done
                    $button13 = $uniq[0];
                  }else if($movement == "left"){//done
                    $button7 = $uniq[0];
                  }else if($movement == "right"){//done
                    $button17 = $uniq[0];
                  }}else if($buttons13 == $delete_alpha[0]){
                    if($movement == "up"){//done
                      $button12 = $uniq[0];
                    }else if($movement == "down"){//done
                      $button14 = $uniq[0];//hahahahahahahahahahahahhahahahah
                    }else if($movement == "left"){//done
                      $button8 = $uniq[0];
                    }else if($movement == "right"){//done
                      $button18 = $uniq[0];
                    }}else if($buttons14 == $delete_alpha[0]){
                      if($movement == "up"){
                        $button13 = $uniq[0];
                      }else if($movement == "down"){
                        $button15 = $uniq[0];
                      }else if($movement == "left"){
                        $button9 = $uniq[0];
                      }else if($movement == "right"){
                        $button19 = $uniq[0];
                      }}else if($buttons15 == $delete_alpha[0]){
                        if($movement == "up"){
                          $button14 = $uniq[0];
                        }else if($movement == "down"){
                          $button11 = $uniq[0];
                        }else if($movement == "left"){
                          $button10 = $uniq[0];
                        }else if($movement == "right"){
                          $button20 = $uniq[0];
                        }}else if($buttons16 == $delete_alpha[0]){
                          if($movement == "up"){//done
                            $button20 = $uniq[0];
                          }else if($movement == "down"){//done
                            $button17 = $uniq[0];
                          }else if($movement == "left"){//done
                            $button11 = $uniq[0];
                          }else if($movement == "right"){//done
                            $button21 = $uniq[0];
                          }}else if($buttons17 == $delete_alpha[0]){
                          if($movement == "up"){//done
                            $button16 = $uniq[0];
                          }else if($movement == "down"){//done
                            $button18 = $uniq[0];
                          }else if($movement == "left"){//done
                            $button12 = $uniq[0];
                          }else if($movement == "right"){//done
                            $button22 = $uniq[0];
                          }}else if($buttons18 == $delete_alpha[0]){
                            if($movement == "up"){//done
                              $button17 = $uniq[0];
                            }else if($movement == "down"){//done
                              $button19 = $uniq[0];
                            }else if($movement == "left"){//done
                              $button13 = $uniq[0];
                            }else if($movement == "right"){//done
                              $button23 = $uniq[0];
                            }}else if($buttons19 == $delete_alpha[0]){
                              if($movement == "up"){
                                $button18 = $uniq[0];
                              }else if($movement == "down"){
                                $button20 = $uniq[0];
                              }else if($movement == "left"){
                                $button14 = $uniq[0];
                              }else if($movement == "right"){
                                $button24 = $uniq[0];
                              }}else if($buttons20 == $delete_alpha[0]){
                                if($movement == "up"){
                                  $button19 = $uniq[0];
                                }else if($movement == "down"){
                                  $button16 = $uniq[0];
                                }else if($movement == "left"){
                                  $button15 = $uniq[0];
                                }else if($movement == "right"){
                                  $button25 = $uniq[0];
                                }
                              }else if($buttons21 == $delete_alpha[0]){
                                if($movement == "up"){//end hahahahahahahahahahahahhahahahah
                                  $button25 = $uniq[0];
                                }else if($movement == "down"){
                                  $button22 = $uniq[0];
                                }else if($movement == "left"){
                                  $button16 = $uniq[0];
                                }else if($movement == "right"){
                                  $button1 = $uniq[0];
                                }}else if($buttons22 == $delete_alpha[0]){
                                  if($movement == "up"){//done
                                    $button21 = $uniq[0];
                                  }else if($movement == "down"){//done
                                    $button23 = $uniq[0];
                                  }else if($movement == "left"){//done
                                    $button17 = $uniq[0];
                                  }else if($movement == "right"){//done
                                    $button2 = $uniq[0];
                                  }}else if($buttons23 == $delete_alpha[0]){
                                  if($movement == "up"){//done
                                    $button22 = $uniq[0];
                                  }else if($movement == "down"){//done
                                    $button24 = $uniq[0];
                                  }else if($movement == "left"){//done
                                    $button18 = $uniq[0];
                                  }else if($movement == "right"){//done
                                    $button3 = $uniq[0];
                                  }}else if($buttons24 == $delete_alpha[0]){
                                    if($movement == "up"){//done
                                      $button23 = $uniq[0];
                                    }else if($movement == "down"){//done
                                      $button25 = $uniq[0];
                                    }else if($movement == "left"){//done
                                      $button19 = $uniq[0];
                                    }else if($movement == "right"){//done
                                      $button4 = $uniq[0];
                                    }}else if($buttons25 == $delete_alpha[0]){
                                      if($movement == "up"){
                                        $button24 = $uniq[0];
                                      }else if($movement == "down"){
                                        $button21 = $uniq[0];
                                      }else if($movement == "left"){
                                        $button20 = $uniq[0];
                                      }else if($movement == "right"){
                                        $button5 = $uniq[0];
                                      }}

                                      if($buttons1 == $delete_alpha[1]){
                                        if($movement == "up"){//done
                                          $button5 = $uniq[1];
                                        }else if($movement == "down"){//done
                                          $button2 = $uniq[1];
                                        }else if($movement == "left"){//done
                                          $button21 = $uniq[1];
                                        }else if($movement == "right"){//done
                                          $button6 = $uniq[1];
                                        }
                                      }else if($buttons2 == $delete_alpha[1]){
                                        if($movement == "up"){//done
                                          $button1 = $uniq[1];
                                        }else if($movement == "down"){//done
                                          $button3 = $uniq[1];
                                        }else if($movement == "left"){//done
                                          $button22 = $uniq[1];
                                        }else if($movement == "right"){//done
                                          $button7 = $uniq[1];
                                        }}else if($buttons3 == $delete_alpha[1]){
                                          if($movement == "up"){//done
                                            $button2 = $uniq[1];
                                          }else if($movement == "down"){//done
                                            $button4 = $uniq[1];
                                          }else if($movement == "left"){//done
                                            $button23 = $uniq[1];
                                          }else if($movement == "right"){//done
                                            $button8 = $uniq[1];
                                          }}else if($buttons4 == $delete_alpha[1]){
                                            if($movement == "up"){
                                              $button3 = $uniq[1];
                                            }else if($movement == "down"){
                                              $button5 = $uniq[1];
                                            }else if($movement == "left"){
                                              $button24 = $uniq[1];
                                            }else if($movement == "right"){
                                              $button9 = $uniq[1];
                                            }}else if($buttons5 == $delete_alpha[1]){
                                              if($movement == "up"){
                                                $button4 = $uniq[1];
                                              }else if($movement == "down"){
                                                $button1 = $uniq[1];
                                              }else if($movement == "left"){
                                                $button25 = $uniq[1];
                                              }else if($movement == "right"){
                                                $button10 = $uniq[1];
                                              }}else if($buttons6 == $delete_alpha[1]){
                                                if($movement == "up"){//done
                                                  $button10 = $uniq[1];
                                                }else if($movement == "down"){//done
                                                  $button7 = $uniq[1];
                                                }else if($movement == "left"){//done
                                                  $button1 = $uniq[1];
                                                }else if($movement == "right"){//done
                                                  $button11 = $uniq[1];
                                                }}else if($buttons7 == $delete_alpha[1]){
                                                if($movement == "up"){//done
                                                  $button6 = $uniq[1];
                                                }else if($movement == "down"){//done
                                                  $button8 = $uniq[1];
                                                }else if($movement == "left"){//done
                                                  $button2 = $uniq[1];
                                                }else if($movement == "right"){//done
                                                  $button12 = $uniq[1];
                                                }}else if($buttons8 == $delete_alpha[1]){
                                                  if($movement == "up"){//done
                                                    $button7 = $uniq[1];
                                                  }else if($movement == "down"){//done
                                                    $button9 = $uniq[1];
                                                  }else if($movement == "left"){//done
                                                    $button3 = $uniq[1];
                                                  }else if($movement == "right"){//done
                                                    $button13 = $uniq[1];
                                                  }}else if($buttons9 == $delete_alpha[1]){
                                                    if($movement == "up"){
                                                      $button8 = $uniq[1];
                                                    }else if($movement == "down"){
                                                      $button10 = $uniq[1];
                                                    }else if($movement == "left"){
                                                      $button4 = $uniq[1];
                                                    }else if($movement == "right"){
                                                      $button14 = $uniq[1];
                                                    }}else if($buttons10 == $delete_alpha[1]){
                                                      if($movement == "up"){
                                                        $button9 = $uniq[1];
                                                      }else if($movement == "down"){
                                                        $button6 = $uniq[1];
                                                      }else if($movement == "left"){
                                                        $button5 = $uniq[1];
                                                      }else if($movement == "right"){
                                                        $button15 = $uniq[1];
                                                      }
                                                    }else if($buttons11 == $delete_alpha[1]){
                                                        if($movement == "up"){//done
                                                          $button15 = $uniq[1];
                                                        }else if($movement == "down"){//done
                                                          $button12 = $uniq[1];
                                                        }else if($movement == "left"){//done
                                                          $button6 = $uniq[1];
                                                        }else if($movement == "right"){//done
                                                          $button16 = $uniq[1];
                                                        }}else if($buttons12 == $delete_alpha[1]){
                                                        if($movement == "up"){//done
                                                          $button11 = $uniq[1];
                                                        }else if($movement == "down"){//done
                                                          $button13 = $uniq[1];
                                                        }else if($movement == "left"){//done
                                                          $button7 = $uniq[1];
                                                        }else if($movement == "right"){//done
                                                          $button17 = $uniq[1];
                                                        }}else if($buttons13 == $delete_alpha[1]){
                                                          if($movement == "up"){//done
                                                            $button12 = $uniq[1];
                                                          }else if($movement == "down"){//done
                                                            $button14 = $uniq[1];//hahahahahahahahahahahahhahahahah
                                                          }else if($movement == "left"){//done
                                                            $button8 = $uniq[1];
                                                          }else if($movement == "right"){//done
                                                            $button18 = $uniq[1];
                                                          }}else if($buttons14 == $delete_alpha[1]){
                                                            if($movement == "up"){
                                                              $button13 = $uniq[1];
                                                            }else if($movement == "down"){
                                                              $button15 = $uniq[1];
                                                            }else if($movement == "left"){
                                                              $button9 = $uniq[1];
                                                            }else if($movement == "right"){
                                                              $button19 = $uniq[1];
                                                            }}else if($buttons15 == $delete_alpha[1]){
                                                              if($movement == "up"){
                                                                $button14 = $uniq[1];
                                                              }else if($movement == "down"){
                                                                $button11 = $uniq[1];
                                                              }else if($movement == "left"){
                                                                $button10 = $uniq[1];
                                                              }else if($movement == "right"){
                                                                $button20 = $uniq[1];
                                                              }}else if($buttons16 == $delete_alpha[1]){
                                                                if($movement == "up"){//done
                                                                  $button20 = $uniq[1];
                                                                }else if($movement == "down"){//done
                                                                  $button17 = $uniq[1];
                                                                }else if($movement == "left"){//done
                                                                  $button11 = $uniq[1];
                                                                }else if($movement == "right"){//done
                                                                  $button21 = $uniq[1];
                                                                }}else if($buttons17 == $delete_alpha[1]){
                                                                if($movement == "up"){//done
                                                                  $button16 = $uniq[1];
                                                                }else if($movement == "down"){//done
                                                                  $button18 = $uniq[1];
                                                                }else if($movement == "left"){//done
                                                                  $button12 = $uniq[1];
                                                                }else if($movement == "right"){//done
                                                                  $button22 = $uniq[1];
                                                                }}else if($buttons18 == $delete_alpha[1]){
                                                                  if($movement == "up"){//done
                                                                    $button17 = $uniq[1];
                                                                  }else if($movement == "down"){//done
                                                                    $button19 = $uniq[1];
                                                                  }else if($movement == "left"){//done
                                                                    $button13 = $uniq[1];
                                                                  }else if($movement == "right"){//done
                                                                    $button23 = $uniq[1];
                                                                  }}else if($buttons19 == $delete_alpha[1]){
                                                                    if($movement == "up"){
                                                                      $button18 = $uniq[1];
                                                                    }else if($movement == "down"){
                                                                      $button20 = $uniq[1];
                                                                    }else if($movement == "left"){
                                                                      $button14 = $uniq[1];
                                                                    }else if($movement == "right"){
                                                                      $button24 = $uniq[1];
                                                                    }}else if($buttons20 == $delete_alpha[1]){
                                                                      if($movement == "up"){
                                                                        $button19 = $uniq[1];
                                                                      }else if($movement == "down"){
                                                                        $button16 = $uniq[1];
                                                                      }else if($movement == "left"){
                                                                        $button15 = $uniq[1];
                                                                      }else if($movement == "right"){
                                                                        $button25 = $uniq[1];
                                                                      }
                                                                    }else if($buttons21 == $delete_alpha[1]){
                                                                      if($movement == "up"){//end hahahahahahahahahahahahhahahahah
                                                                        $button25 = $uniq[1];
                                                                      }else if($movement == "down"){
                                                                        $button22 = $uniq[1];
                                                                      }else if($movement == "left"){
                                                                        $button16 = $uniq[1];
                                                                      }else if($movement == "right"){
                                                                        $button1 = $uniq[1];
                                                                      }}else if($buttons22 == $delete_alpha[1]){
                                                                        if($movement == "up"){//done
                                                                          $button21 = $uniq[1];
                                                                        }else if($movement == "down"){//done
                                                                          $button23 = $uniq[1];
                                                                        }else if($movement == "left"){//done
                                                                          $button17 = $uniq[1];
                                                                        }else if($movement == "right"){//done
                                                                          $button2 = $uniq[1];
                                                                        }}else if($buttons23 == $delete_alpha[1]){
                                                                        if($movement == "up"){//done
                                                                          $button22 = $uniq[1];
                                                                        }else if($movement == "down"){//done
                                                                          $button24 = $uniq[1];
                                                                        }else if($movement == "left"){//done
                                                                          $button18 = $uniq[1];
                                                                        }else if($movement == "right"){//done
                                                                          $button3 = $uniq[1];
                                                                        }}else if($buttons24 == $delete_alpha[1]){
                                                                          if($movement == "up"){//done
                                                                            $button23 = $uniq[1];
                                                                          }else if($movement == "down"){//done
                                                                            $button25 = $uniq[1];
                                                                          }else if($movement == "left"){//done
                                                                            $button19 = $uniq[1];
                                                                          }else if($movement == "right"){//done
                                                                            $button4 = $uniq[1];
                                                                          }}else if($buttons25 == $delete_alpha[1]){
                                                                            if($movement == "up"){
                                                                              $button24 = $uniq[1];
                                                                            }else if($movement == "down"){
                                                                              $button21 = $uniq[1];
                                                                            }else if($movement == "left"){
                                                                              $button20 = $uniq[1];
                                                                            }else if($movement == "right"){
                                                                              $button5 = $uniq[1];
                                                                            }}

                                                                            if($buttons1 == $delete_alpha[2]){
                                                                              if($movement == "up"){//done
                                                                                $button5 = $uniq[2];
                                                                              }else if($movement == "down"){//done
                                                                                $button2 = $uniq[2];
                                                                              }else if($movement == "left"){//done
                                                                                $button21 = $uniq[2];
                                                                              }else if($movement == "right"){//done
                                                                                $button6 = $uniq[2];
                                                                              }
                                                                            }else if($buttons2 == $delete_alpha[2]){
                                                                              if($movement == "up"){//done
                                                                                $button1 = $uniq[2];
                                                                              }else if($movement == "down"){//done
                                                                                $button3 = $uniq[2];
                                                                              }else if($movement == "left"){//done
                                                                                $button22 = $uniq[2];
                                                                              }else if($movement == "right"){//done
                                                                                $button7 = $uniq[2];
                                                                              }}else if($buttons3 == $delete_alpha[2]){
                                                                                if($movement == "up"){//done
                                                                                  $button2 = $uniq[2];
                                                                                }else if($movement == "down"){//done
                                                                                  $button4 = $uniq[2];
                                                                                }else if($movement == "left"){//done
                                                                                  $button23 = $uniq[2];
                                                                                }else if($movement == "right"){//done
                                                                                  $button8 = $uniq[2];
                                                                                }}else if($buttons4 == $delete_alpha[2]){
                                                                                  if($movement == "up"){
                                                                                    $button3 = $uniq[2];
                                                                                  }else if($movement == "down"){
                                                                                    $button5 = $uniq[2];
                                                                                  }else if($movement == "left"){
                                                                                    $button24 = $uniq[2];
                                                                                  }else if($movement == "right"){
                                                                                    $button9 = $uniq[2];
                                                                                  }}else if($buttons5 == $delete_alpha[2]){
                                                                                    if($movement == "up"){
                                                                                      $button4 = $uniq[2];
                                                                                    }else if($movement == "down"){
                                                                                      $button1 = $uniq[2];
                                                                                    }else if($movement == "left"){
                                                                                      $button25 = $uniq[2];
                                                                                    }else if($movement == "right"){
                                                                                      $button10 = $uniq[2];
                                                                                    }}else if($buttons6 == $delete_alpha[2]){
                                                                                      if($movement == "up"){//done
                                                                                        $button10 = $uniq[2];
                                                                                      }else if($movement == "down"){//done
                                                                                        $button7 = $uniq[2];
                                                                                      }else if($movement == "left"){//done
                                                                                        $button1 = $uniq[2];
                                                                                      }else if($movement == "right"){//done
                                                                                        $button11 = $uniq[2];
                                                                                      }}else if($buttons7 == $delete_alpha[2]){
                                                                                      if($movement == "up"){//done
                                                                                        $button6 = $uniq[2];
                                                                                      }else if($movement == "down"){//done
                                                                                        $button8 = $uniq[2];
                                                                                      }else if($movement == "left"){//done
                                                                                        $button2 = $uniq[2];
                                                                                      }else if($movement == "right"){//done
                                                                                        $button12 = $uniq[2];
                                                                                      }}else if($buttons8 == $delete_alpha[2]){
                                                                                        if($movement == "up"){//done
                                                                                          $button7 = $uniq[2];
                                                                                        }else if($movement == "down"){//done
                                                                                          $button9 = $uniq[2];
                                                                                        }else if($movement == "left"){//done
                                                                                          $button3 = $uniq[2];
                                                                                        }else if($movement == "right"){//done
                                                                                          $button13 = $uniq[2];
                                                                                        }}else if($buttons9 == $delete_alpha[2]){
                                                                                          if($movement == "up"){
                                                                                            $button8 = $uniq[2];
                                                                                          }else if($movement == "down"){
                                                                                            $button10 = $uniq[2];
                                                                                          }else if($movement == "left"){
                                                                                            $button4 = $uniq[2];
                                                                                          }else if($movement == "right"){
                                                                                            $button14 = $uniq[2];
                                                                                          }}else if($buttons10 == $delete_alpha[2]){
                                                                                            if($movement == "up"){
                                                                                              $button9 = $uniq[2];
                                                                                            }else if($movement == "down"){
                                                                                              $button6 = $uniq[2];
                                                                                            }else if($movement == "left"){
                                                                                              $button5 = $uniq[2];
                                                                                            }else if($movement == "right"){
                                                                                              $button15 = $uniq[2];
                                                                                            }
                                                                                          }else if($buttons11 == $delete_alpha[2]){
                                                                                              if($movement == "up"){//done
                                                                                                $button15 = $uniq[2];
                                                                                              }else if($movement == "down"){//done
                                                                                                $button12 = $uniq[2];
                                                                                              }else if($movement == "left"){//done
                                                                                                $button6 = $uniq[2];
                                                                                              }else if($movement == "right"){//done
                                                                                                $button16 = $uniq[2];
                                                                                              }}else if($buttons12 == $delete_alpha[2]){
                                                                                              if($movement == "up"){//done
                                                                                                $button11 = $uniq[2];
                                                                                              }else if($movement == "down"){//done
                                                                                                $button13 = $uniq[2];
                                                                                              }else if($movement == "left"){//done
                                                                                                $button7 = $uniq[2];
                                                                                              }else if($movement == "right"){//done
                                                                                                $button17 = $uniq[2];
                                                                                              }}else if($buttons13 == $delete_alpha[2]){
                                                                                                if($movement == "up"){//done
                                                                                                  $button12 = $uniq[2];
                                                                                                }else if($movement == "down"){//done
                                                                                                  $button14 = $uniq[2];//hahahahahahahahahahahahhahahahah
                                                                                                }else if($movement == "left"){//done
                                                                                                  $button8 = $uniq[2];
                                                                                                }else if($movement == "right"){//done
                                                                                                  $button18 = $uniq[2];
                                                                                                }}else if($buttons14 == $delete_alpha[2]){
                                                                                                  if($movement == "up"){
                                                                                                    $button13 = $uniq[2];
                                                                                                  }else if($movement == "down"){
                                                                                                    $button15 = $uniq[2];
                                                                                                  }else if($movement == "left"){
                                                                                                    $button9 = $uniq[2];
                                                                                                  }else if($movement == "right"){
                                                                                                    $button19 = $uniq[2];
                                                                                                  }}else if($buttons15 == $delete_alpha[2]){
                                                                                                    if($movement == "up"){
                                                                                                      $button14 = $uniq[2];
                                                                                                    }else if($movement == "down"){
                                                                                                      $button11 = $uniq[2];
                                                                                                    }else if($movement == "left"){
                                                                                                      $button10 = $uniq[2];
                                                                                                    }else if($movement == "right"){
                                                                                                      $button20 = $uniq[2];
                                                                                                    }}else if($buttons16 == $delete_alpha[2]){
                                                                                                      if($movement == "up"){//done
                                                                                                        $button20 = $uniq[2];
                                                                                                      }else if($movement == "down"){//done
                                                                                                        $button17 = $uniq[2];
                                                                                                      }else if($movement == "left"){//done
                                                                                                        $button11 = $uniq[2];
                                                                                                      }else if($movement == "right"){//done
                                                                                                        $button21 = $uniq[2];
                                                                                                      }}else if($buttons17 == $delete_alpha[2]){
                                                                                                      if($movement == "up"){//done
                                                                                                        $button16 = $uniq[2];
                                                                                                      }else if($movement == "down"){//done
                                                                                                        $button18 = $uniq[2];
                                                                                                      }else if($movement == "left"){//done
                                                                                                        $button12 = $uniq[2];
                                                                                                      }else if($movement == "right"){//done
                                                                                                        $button22 = $uniq[2];
                                                                                                      }}else if($buttons18 == $delete_alpha[2]){
                                                                                                        if($movement == "up"){//done
                                                                                                          $button17 = $uniq[2];
                                                                                                        }else if($movement == "down"){//done
                                                                                                          $button19 = $uniq[2];
                                                                                                        }else if($movement == "left"){//done
                                                                                                          $button13 = $uniq[2];
                                                                                                        }else if($movement == "right"){//done
                                                                                                          $button23 = $uniq[2];
                                                                                                        }}else if($buttons19 == $delete_alpha[2]){
                                                                                                          if($movement == "up"){
                                                                                                            $button18 = $uniq[2];
                                                                                                          }else if($movement == "down"){
                                                                                                            $button20 = $uniq[2];
                                                                                                          }else if($movement == "left"){
                                                                                                            $button14 = $uniq[2];
                                                                                                          }else if($movement == "right"){
                                                                                                            $button24 = $uniq[2];
                                                                                                          }}else if($buttons20 == $delete_alpha[2]){
                                                                                                            if($movement == "up"){
                                                                                                              $button19 = $uniq[2];
                                                                                                            }else if($movement == "down"){
                                                                                                              $button16 = $uniq[2];
                                                                                                            }else if($movement == "left"){
                                                                                                              $button15 = $uniq[2];
                                                                                                            }else if($movement == "right"){
                                                                                                              $button25 = $uniq[2];
                                                                                                            }
                                                                                                          }else if($buttons21 == $delete_alpha[2]){
                                                                                                            if($movement == "up"){//end hahahahahahahahahahahahhahahahah
                                                                                                              $button25 = $uniq[2];
                                                                                                            }else if($movement == "down"){
                                                                                                              $button22 = $uniq[2];
                                                                                                            }else if($movement == "left"){
                                                                                                              $button16 = $uniq[2];
                                                                                                            }else if($movement == "right"){
                                                                                                              $button1 = $uniq[2];
                                                                                                            }}else if($buttons22 == $delete_alpha[2]){
                                                                                                              if($movement == "up"){//done
                                                                                                                $button21 = $uniq[2];
                                                                                                              }else if($movement == "down"){//done
                                                                                                                $button23 = $uniq[2];
                                                                                                              }else if($movement == "left"){//done
                                                                                                                $button17 = $uniq[2];
                                                                                                              }else if($movement == "right"){//done
                                                                                                                $button2 = $uniq[2];
                                                                                                              }}else if($buttons23 == $delete_alpha[2]){
                                                                                                              if($movement == "up"){//done
                                                                                                                $button22 = $uniq[2];
                                                                                                              }else if($movement == "down"){//done
                                                                                                                $button24 = $uniq[2];
                                                                                                              }else if($movement == "left"){//done
                                                                                                                $button18 = $uniq[2];
                                                                                                              }else if($movement == "right"){//done
                                                                                                                $button3 = $uniq[2];
                                                                                                              }}else if($buttons24 == $delete_alpha[2]){
                                                                                                                if($movement == "up"){//done
                                                                                                                  $button23 = $uniq[2];
                                                                                                                }else if($movement == "down"){//done
                                                                                                                  $button25 = $uniq[2];
                                                                                                                }else if($movement == "left"){//done
                                                                                                                  $button19 = $uniq[2];
                                                                                                                }else if($movement == "right"){//done
                                                                                                                  $button4 = $uniq[2];
                                                                                                                }}else if($buttons25 == $delete_alpha[2]){
                                                                                                                  if($movement == "up"){
                                                                                                                    $button24 = $uniq[2];
                                                                                                                  }else if($movement == "down"){
                                                                                                                    $button21 = $uniq[2];
                                                                                                                  }else if($movement == "left"){
                                                                                                                    $button20 = $uniq[2];
                                                                                                                  }else if($movement == "right"){
                                                                                                                    $button5 = $uniq[2];
                                                                                                                  }}

                                                                                                                  if($buttons1 == $delete_alpha[3]){
                                                                                                                    if($movement == "up"){//done
                                                                                                                      $button5 = $uniq[3];
                                                                                                                    }else if($movement == "down"){//done
                                                                                                                      $button2 = $uniq[3];
                                                                                                                    }else if($movement == "left"){//done
                                                                                                                      $button21 = $uniq[3];
                                                                                                                    }else if($movement == "right"){//done
                                                                                                                      $button6 = $uniq[3];
                                                                                                                    }
                                                                                                                  }else if($buttons2 == $delete_alpha[3]){
                                                                                                                    if($movement == "up"){//done
                                                                                                                      $button1 = $uniq[3];
                                                                                                                    }else if($movement == "down"){//done
                                                                                                                      $button3 = $uniq[3];
                                                                                                                    }else if($movement == "left"){//done
                                                                                                                      $button22 = $uniq[3];
                                                                                                                    }else if($movement == "right"){//done
                                                                                                                      $button7 = $uniq[3];
                                                                                                                    }}else if($buttons3 == $delete_alpha[3]){
                                                                                                                      if($movement == "up"){//done
                                                                                                                        $button2 = $uniq[3];
                                                                                                                      }else if($movement == "down"){//done
                                                                                                                        $button4 = $uniq[3];
                                                                                                                      }else if($movement == "left"){//done
                                                                                                                        $button23 = $uniq[3];
                                                                                                                      }else if($movement == "right"){//done
                                                                                                                        $button8 = $uniq[3];
                                                                                                                      }}else if($buttons4 == $delete_alpha[3]){
                                                                                                                        if($movement == "up"){
                                                                                                                          $button3 = $uniq[3];
                                                                                                                        }else if($movement == "down"){
                                                                                                                          $button5 = $uniq[3];
                                                                                                                        }else if($movement == "left"){
                                                                                                                          $button24 = $uniq[3];
                                                                                                                        }else if($movement == "right"){
                                                                                                                          $button9 = $uniq[3];
                                                                                                                        }}else if($buttons5 == $delete_alpha[3]){
                                                                                                                          if($movement == "up"){
                                                                                                                            $button4 = $uniq[3];
                                                                                                                          }else if($movement == "down"){
                                                                                                                            $button1 = $uniq[3];
                                                                                                                          }else if($movement == "left"){
                                                                                                                            $button25 = $uniq[3];
                                                                                                                          }else if($movement == "right"){
                                                                                                                            $button10 = $uniq[3];
                                                                                                                          }}else if($buttons6 == $delete_alpha[3]){
                                                                                                                            if($movement == "up"){//done
                                                                                                                              $button10 = $uniq[3];
                                                                                                                            }else if($movement == "down"){//done
                                                                                                                              $button7 = $uniq[3];
                                                                                                                            }else if($movement == "left"){//done
                                                                                                                              $button1 = $uniq[3];
                                                                                                                            }else if($movement == "right"){//done
                                                                                                                              $button11 = $uniq[3];
                                                                                                                            }}else if($buttons7 == $delete_alpha[3]){
                                                                                                                            if($movement == "up"){//done
                                                                                                                              $button6 = $uniq[3];
                                                                                                                            }else if($movement == "down"){//done
                                                                                                                              $button8 = $uniq[3];
                                                                                                                            }else if($movement == "left"){//done
                                                                                                                              $button2 = $uniq[3];
                                                                                                                            }else if($movement == "right"){//done
                                                                                                                              $button12 = $uniq[3];
                                                                                                                            }}else if($buttons8 == $delete_alpha[3]){
                                                                                                                              if($movement == "up"){//done
                                                                                                                                $button7 = $uniq[3];
                                                                                                                              }else if($movement == "down"){//done
                                                                                                                                $button9 = $uniq[3];
                                                                                                                              }else if($movement == "left"){//done
                                                                                                                                $button3 = $uniq[3];
                                                                                                                              }else if($movement == "right"){//done
                                                                                                                                $button13 = $uniq[3];
                                                                                                                              }}else if($buttons9 == $delete_alpha[3]){
                                                                                                                                if($movement == "up"){
                                                                                                                                  $button8 = $uniq[3];
                                                                                                                                }else if($movement == "down"){
                                                                                                                                  $button10 = $uniq[3];
                                                                                                                                }else if($movement == "left"){
                                                                                                                                  $button4 = $uniq[3];
                                                                                                                                }else if($movement == "right"){
                                                                                                                                  $button14 = $uniq[3];
                                                                                                                                }}else if($buttons10 == $delete_alpha[3]){
                                                                                                                                  if($movement == "up"){
                                                                                                                                    $button9 = $uniq[3];
                                                                                                                                  }else if($movement == "down"){
                                                                                                                                    $button6 = $uniq[3];
                                                                                                                                  }else if($movement == "left"){
                                                                                                                                    $button5 = $uniq[3];
                                                                                                                                  }else if($movement == "right"){
                                                                                                                                    $button15 = $uniq[3];
                                                                                                                                  }
                                                                                                                                }else if($buttons11 == $delete_alpha[3]){
                                                                                                                                    if($movement == "up"){//done
                                                                                                                                      $button15 = $uniq[3];
                                                                                                                                    }else if($movement == "down"){//done
                                                                                                                                      $button12 = $uniq[3];
                                                                                                                                    }else if($movement == "left"){//done
                                                                                                                                      $button6 = $uniq[3];
                                                                                                                                    }else if($movement == "right"){//done
                                                                                                                                      $button16 = $uniq[3];
                                                                                                                                    }}else if($buttons12 == $delete_alpha[3]){
                                                                                                                                    if($movement == "up"){//done
                                                                                                                                      $button11 = $uniq[3];
                                                                                                                                    }else if($movement == "down"){//done
                                                                                                                                      $button13 = $uniq[3];
                                                                                                                                    }else if($movement == "left"){//done
                                                                                                                                      $button7 = $uniq[3];
                                                                                                                                    }else if($movement == "right"){//done
                                                                                                                                      $button17 = $uniq[3];
                                                                                                                                    }}else if($buttons13 == $delete_alpha[3]){
                                                                                                                                      if($movement == "up"){//done
                                                                                                                                        $button12 = $uniq[3];
                                                                                                                                      }else if($movement == "down"){//done
                                                                                                                                        $button14 = $uniq[3];//hahahahahahahahahahahahhahahahah
                                                                                                                                      }else if($movement == "left"){//done
                                                                                                                                        $button8 = $uniq[3];
                                                                                                                                      }else if($movement == "right"){//done
                                                                                                                                        $button18 = $uniq[3];
                                                                                                                                      }}else if($buttons14 == $delete_alpha[3]){
                                                                                                                                        if($movement == "up"){
                                                                                                                                          $button13 = $uniq[3];
                                                                                                                                        }else if($movement == "down"){
                                                                                                                                          $button15 = $uniq[3];
                                                                                                                                        }else if($movement == "left"){
                                                                                                                                          $button9 = $uniq[3];
                                                                                                                                        }else if($movement == "right"){
                                                                                                                                          $button19 = $uniq[3];
                                                                                                                                        }}else if($buttons15 == $delete_alpha[3]){
                                                                                                                                          if($movement == "up"){
                                                                                                                                            $button14 = $uniq[3];
                                                                                                                                          }else if($movement == "down"){
                                                                                                                                            $button11 = $uniq[3];
                                                                                                                                          }else if($movement == "left"){
                                                                                                                                            $button10 = $uniq[3];
                                                                                                                                          }else if($movement == "right"){
                                                                                                                                            $button20 = $uniq[3];
                                                                                                                                          }}else if($buttons16 == $delete_alpha[3]){
                                                                                                                                            if($movement == "up"){//done
                                                                                                                                              $button20 = $uniq[3];
                                                                                                                                            }else if($movement == "down"){//done
                                                                                                                                              $button17 = $uniq[3];
                                                                                                                                            }else if($movement == "left"){//done
                                                                                                                                              $button11 = $uniq[3];
                                                                                                                                            }else if($movement == "right"){//done
                                                                                                                                              $button21 = $uniq[3];
                                                                                                                                            }}else if($buttons17 == $delete_alpha[3]){
                                                                                                                                            if($movement == "up"){//done
                                                                                                                                              $button16 = $uniq[3];
                                                                                                                                            }else if($movement == "down"){//done
                                                                                                                                              $button18 = $uniq[3];
                                                                                                                                            }else if($movement == "left"){//done
                                                                                                                                              $button12 = $uniq[3];
                                                                                                                                            }else if($movement == "right"){//done
                                                                                                                                              $button22 = $uniq[3];
                                                                                                                                            }}else if($buttons18 == $delete_alpha[3]){
                                                                                                                                              if($movement == "up"){//done
                                                                                                                                                $button17 = $uniq[3];
                                                                                                                                              }else if($movement == "down"){//done
                                                                                                                                                $button19 = $uniq[3];
                                                                                                                                              }else if($movement == "left"){//done
                                                                                                                                                $button13 = $uniq[3];
                                                                                                                                              }else if($movement == "right"){//done
                                                                                                                                                $button23 = $uniq[3];
                                                                                                                                              }}else if($buttons19 == $delete_alpha[3]){
                                                                                                                                                if($movement == "up"){
                                                                                                                                                  $button18 = $uniq[3];
                                                                                                                                                }else if($movement == "down"){
                                                                                                                                                  $button20 = $uniq[3];
                                                                                                                                                }else if($movement == "left"){
                                                                                                                                                  $button14 = $uniq[3];
                                                                                                                                                }else if($movement == "right"){
                                                                                                                                                  $button24 = $uniq[3];
                                                                                                                                                }}else if($buttons20 == $delete_alpha[3]){
                                                                                                                                                  if($movement == "up"){
                                                                                                                                                    $button19 = $uniq[3];
                                                                                                                                                  }else if($movement == "down"){
                                                                                                                                                    $button16 = $uniq[3];
                                                                                                                                                  }else if($movement == "left"){
                                                                                                                                                    $button15 = $uniq[3];
                                                                                                                                                  }else if($movement == "right"){
                                                                                                                                                    $button25 = $uniq[3];
                                                                                                                                                  }
                                                                                                                                                }else if($buttons21 == $delete_alpha[3]){
                                                                                                                                                  if($movement == "up"){//end hahahahahahahahahahahahhahahahah
                                                                                                                                                    $button25 = $uniq[3];
                                                                                                                                                  }else if($movement == "down"){
                                                                                                                                                    $button22 = $uniq[3];
                                                                                                                                                  }else if($movement == "left"){
                                                                                                                                                    $button16 = $uniq[3];
                                                                                                                                                  }else if($movement == "right"){
                                                                                                                                                    $button1 = $uniq[3];
                                                                                                                                                  }}else if($buttons22 == $delete_alpha[3]){
                                                                                                                                                    if($movement == "up"){//done
                                                                                                                                                      $button21 = $uniq[3];
                                                                                                                                                    }else if($movement == "down"){//done
                                                                                                                                                      $button23 = $uniq[3];
                                                                                                                                                    }else if($movement == "left"){//done
                                                                                                                                                      $button17 = $uniq[3];
                                                                                                                                                    }else if($movement == "right"){//done
                                                                                                                                                      $button2 = $uniq[3];
                                                                                                                                                    }}else if($buttons23 == $delete_alpha[3]){
                                                                                                                                                    if($movement == "up"){//done
                                                                                                                                                      $button22 = $uniq[3];
                                                                                                                                                    }else if($movement == "down"){//done
                                                                                                                                                      $button24 = $uniq[3];
                                                                                                                                                    }else if($movement == "left"){//done
                                                                                                                                                      $button18 = $uniq[3];
                                                                                                                                                    }else if($movement == "right"){//done
                                                                                                                                                      $button3 = $uniq[3];
                                                                                                                                                    }}else if($buttons24 == $delete_alpha[3]){
                                                                                                                                                      if($movement == "up"){//done
                                                                                                                                                        $button23 = $uniq[3];
                                                                                                                                                      }else if($movement == "down"){//done
                                                                                                                                                        $button25 = $uniq[3];
                                                                                                                                                      }else if($movement == "left"){//done
                                                                                                                                                        $button19 = $uniq[3];
                                                                                                                                                      }else if($movement == "right"){//done
                                                                                                                                                        $button4 = $uniq[3];
                                                                                                                                                      }}else if($buttons25 == $delete_alpha[3]){
                                                                                                                                                        if($movement == "up"){
                                                                                                                                                          $button24 = $uniq[3];
                                                                                                                                                        }else if($movement == "down"){
                                                                                                                                                          $button21 = $uniq[3];
                                                                                                                                                        }else if($movement == "left"){
                                                                                                                                                          $button20 = $uniq[3];
                                                                                                                                                        }else if($movement == "right"){
                                                                                                                                                          $button5 = $uniq[3];
                                                                                                                                                        }}



}else{
  echo "Error";
}


?>

<head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="include/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/util.css">
	<link rel="stylesheet" type="text/css" href="include/css/main.css">
<!--===============================================================================================-->
</head>
<div class="limiter">
  <div class="container-login100">
    <div class="wrap-login100">
      <h1>Please complete your puzzle</h1><br/>
      <h3>Hint: First word of last 4 character in your password</h3>
      <br>
      <br>

<form action="puzzle.php" method="post">

<div class="row">
    <div class="col-sm-2 col-xs-12">
        <div data-toggle="buttons">
            <div class="switch"><label class="btn btn-block btn-success">
                <input type="checkbox" class="cbx" name="check[]" value="<?php echo "$button1" ?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons1";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
              <input type="checkbox" name="check[]" value="<?php echo "$button2";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons2";?>.jpg" height="10%" width="50%"></label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button3";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons3";?>.jpg" height="10%" width="50%"></label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button4";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons4";?>.jpg" height="10%" width="50%"></label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button5";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons5";?>.jpg" height="10%" width="50%"></label></div>
        </div>
    </div>
    <div class="col-sm-2 col-xs-12">
        <div data-toggle="buttons">
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button6";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons6";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button7";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons7";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button8";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons8";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button9";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons9";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button10";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons10";?>.jpg" height="10%" width="50%">
            </label></div>
        </div>
    </div>
    <div class="col-sm-2 col-xs-12">
        <div data-toggle="buttons">
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button11";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons11";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button12";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons12";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button13";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons13";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button14";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons14";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button15";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons15";?>.jpg" height="10%" width="50%">
            </label></div>
        </div>
    </div>
    <div class="col-sm-2 col-xs-12">
        <div data-toggle="buttons">
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button16";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons16";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button17";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons17";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button18";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons18";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button19";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons19";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button20";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons20";?>.jpg" height="10%" width="50%">
            </label></div>
        </div>
    </div>
    <div class="col-sm-2 col-xs-12">
        <div data-toggle="buttons">
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button21";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons21";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button22";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons22";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button23";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons23";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button24";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons24";?>.jpg" height="10%" width="50%">
            </label></div>
            <div class="switch"><label class="btn btn-block btn-success">
<input type="checkbox" name="check[]" value="<?php echo "$button25";?>" autocomplete="off"><img src="include/captcha/<?php echo "$buttons25";?>.jpg" height="10%" width="50%">
            </label></div>
        </div>
    </div>
</div>
<p><input type="submit" name="continue" value="continue" class="btn btn-block btn-success"></p>
</form>
</div>
</div>
</div>
<?php

if(isset($_POST['continue'])){
$confirmation = $_POST['check'];
$testkey = implode($uniq,"");
$showkey = implode($confirmation,"");
echo "$showkey";
if(!empty($confirmation[0])){
$has_key1 = strpos($testkey, $confirmation[0]) !== false;}else{
$has_key1 = "";
}
if(!empty($confirmation[1])){
$has_key2 = strpos($testkey, $confirmation[1]) !== false;}else{
$has_key2 = "";
}
if(!empty($confirmation[2])){
$has_key3 = strpos($testkey, $confirmation[2]) !== false;}else{
$has_key3 = "";
}
if(!empty($confirmation[3])){
$has_key4 = strpos($testkey, $confirmation[3]) !== false;}else{
$has_key4 = "";
}

if(!empty($has_key1) && !empty($has_key2) && !empty($has_key3) && !empty($has_key4)){
echo '<meta http-equiv="refresh" content="0; url=../">';
}else{
  $_SESSION['count']++;

  if($_SESSION['count'] == 5){
    echo '<meta http-equiv="refresh" content="0; url=index.php">';
  }
  echo "Please try again";
}
}
 ?>

<script>
if($("btn").hasClass("btn-success")){
  $("btn").removeClass("btn-success");
  $("btn").addClass("btn-success");
});

$('input.cbx').on('change', function() {
     $('label.btn').removeClass("btn-success");
     $('label.btn').addClass("btn-danger");
});
</script>
