<?php
$hostname = "localhost";
$user = "root";
$password = "";
$select_db = "fyp";

$db = @mysqli_connect($hostname,$user,$password,$select_db) or mysqli_connect_error();

?>
