<?php
include "include/dbconnect.php";

if(isset($_POST['submit'])){
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $phone = $_POST['phone'];
  $address = $_POST['address'];
  $email = $_POST['email'];
  $movement = $_POST['movement'];

$username = $_POST['username'];
$password1 = $_POST['password1'];
$password2 = $_POST['password2'];

if($password1 == $password2){
  $passwordc = $password1;
}else{
  echo "Password did not match.<br/>";
}

$newstringpass = substr($passwordc, -4);

$length = 4;

$randomletter = substr(str_shuffle("abcdefghijklmnopqrstuvwxyz"), 0, $length);
$query = "insert into login (username,password,keyword,movement,input) values ('$username','$passwordc','$newstringpass','$movement','$randomletter')";
$query1 = "insert into customer (cust_fname,cust_lname,cust_username,cust_phone,cust_address,cust_email) values ('$fname','$lname','$username','$phone','$address','$email')";
$result = mysqli_query($db, $query);
$result1 = mysqli_query($db, $query1);
if($result && $result1){
  ?>
  <script>alert("Data has been saved. Your unique input is "<?php echo $randomletter ?>"");</script>
<?php
echo "Data has been saved. Remember!<p><a href='index.php'>Return to Login</a></p>";
}else{
  ?>
  <script>alert("Error");</script>
<?php
}
}
?>


<!-- Modal -->



<style>
#formtextbox{
  width: 300px;
}
</style>
