<?php 
  
  // start the session
  session_start();
  
  //$page_title = 'Admin Page';
  //include ('./header.html');
  
  /*
  if(isset($_SESSION['username'])){
    echo 'Welcome ' . $_SESSION['username'];
  }
  */
  
  if(isset($_POST['buttonLoginAdmin'])){
    
    require 'connect.php';
    
    $adminusername = $_POST['adminusername'];
    $adminpassword = $_POST['adminpassword'];
    
    $result = mysqli_query($dbc, 'SELECT * FROM admin WHERE admin.adm_username="' . $adminusername . '" and admin.adm_password="' . $adminpassword . '"');
    
    if(mysqli_num_rows($result) == 1){
      
      // sends a raw HTTP header to a client (redirect to another page)
      header('Location:view_users.php');
      
    }else{
      echo 'Invalid account';
    }
    mysqli_close($dbc);
  }
  
?>


<!DOCTYPE html>
<html>

<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
  <header>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Mukta:300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    <nav>
      <div class="main=wrapper">
        <ul>
          <li><a href="index.php">BACK</a></li>
        </ul>
        <div class="nav-login">
            <form action="admin.php" method="POST">
            <input type="text" name="adminusername" placeholder="Username">
            <input type="password" name="adminpassword" placeholder="Password">
            <button type="submit" name="buttonLoginAdmin">Login</button>
            </form>
            
        </div>
      </div>
    </nav>
  </header>
  
  <!--<section class="main-container">-->
    <div class="main-wrapper">
      <div class="site-blocks-cover" style="background-image: url(images/front.jpg);" data-aos="fade">
      <div class="container">
        <div class="row align-items-start align-items-md-center justify-content-end">
          <div class="col-md-5 text-center text-md-left pt-5 pt-md-0">
            <h1 class="mb-2">RESTRICTED TO ADMINISTRATOR ONLY</h1>
            <div class="intro-text text-center text-md-left">
              <p class="mb-4">Other than ADMINISTRATOR please press the "BACK" button on the top left corner</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  <!--</section>-->

    <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
</body>
</html>