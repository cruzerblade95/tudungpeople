<head>
    <title>Tudung Website</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Mukta:300,400,700">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">

    <style>

		#content{
			width: 50%;
			margin: 20px auto;
			border: 1px solid #cbcbcb;
			background-color: #cfd2ff;
		}

		#img_div{
			width: 80%;
			padding: 5px;
			margin: 15px auto;
			border: 1px solid #cbcbcb;
			background-color: #40e0d0;
		}
		#img_div:after{
			content: "";
			display: block;
			clear: both;
		}
		#shirt_img{
			float: left;
			margin: 5px;
			width: 200px;
			height: 140px;
		}

		#demoFont {
			font-family:  sans-serif;
			font-size: 30px;
			letter-spacing: -0.8px;
			word-spacing: 2px;
			color: #092666;
			font-weight: 400;
			text-align:center;
			text-decoration: none;
			font-style: normal;
			font-variant: normal;
			text-transform: none;
		}

		#demoFont2 {
			font-family:  sans-serif;
			font-size: 20px;
			letter-spacing: -0.8px;
			word-spacing: 2px;
			color: #092666;
			font-weight: 400;
			text-align:center;
			text-decoration: none;
			font-style: normal;
			font-variant: normal;
			text-transform: none;
		}

		#demoFont3 {
			font-family: sans-serif;
			font-size: 25px;
			letter-spacing: -0.8px;
			word-spacing: 2px;
			color: #092666;
			font-weight: 400;
			text-align:center;
			text-decoration: none;
			font-style: normal;
			font-variant: normal;
			text-transform: none;
		}

	</style>
  </head>

	<title>Confirm Order</title>
</head>
<?php

	// start the session
	session_start();

	if(isset($_SESSION['id'])){

		//echo 'Id: ' . $_SESSION['id'];
		$id = $_SESSION['id'];

		$cust_id = $_SESSION['id'];

		if(isset($_POST['submit'])){

			// connect to database
			require_once('connect.php');

			// execute query
			$query = "SELECT * FROM customer WHERE customer.cust_id=". $cust_id ."";
			$result = mysqli_query($dbc, $query);

			// fetch the data
			while($row = mysqli_fetch_array($result)){

				$cust_fname = $row['cust_fname'];
				$cust_lname = $row['cust_lname'];
				$cust_username = $row['cust_username'];
				$cust_phone = $row['cust_phone'];
				$cust_email = $row['cust_email'];
				$cust_address = $row['cust_address'];

			}



			echo "<div id='demoFont'>Here is your details ". $cust_username ."</div>";
			echo "<div id='demoFont'>
					<p>First Name: ". $cust_fname ."</p>
					<p>Last Name: ". $cust_lname . "</p>
					<p>Phone Number: ". $cust_phone ."</p>
					<p>Address: ". $cust_address ."</p>
					<p>Email: ". $cust_email ."</p></div>";

			echo "<br>";
			echo "<div id='demoFont3'><p><b>List item(s) of your purchase: </b></p></div>";

			$query = "SELECT * FROM cart";
			$result = mysqli_query($dbc, $query);

			echo "<form action='index.php' method='post' enctype='multipart/form-data'>";

				echo "<div id='content'>";

					// "mysqli_num_rows" returns the number of rows in a result set
				$numarr = mysqli_num_rows($result);

				// selected size array
				$size = array();
				$size = $_POST['cart_size'];

				$count = 0;
				while($row = mysqli_fetch_array($result)){

					echo "<div id='img_div'>";
						echo "<img id='shirt_img' name='pd_image' src='images/" . $row['cart_image'] . "'>";
						echo "<p>" . $row['cart_material'] . "</p>";
						echo "<p>RM " . $row['cart_price'] . "</p>";
						echo "<p>" . $row['cart_name'] . "</p>";
						echo "<p>". $size[$count] ."</p>";

						$cart_image = $row['cart_image'];
						$cart_material = $row['cart_material'];
						$cart_price = $row['cart_price'];
						$cart_name = $row['cart_name'];

						// insert data into order table
						$query2 =  "INSERT INTO orderform(cust_fname, cust_lname, cust_username, cust_phone, cust_email, cust_address, cart_image, cart_material, cart_price, cart_name, cart_size)
							VALUES('$cust_fname', '$cust_lname', '$cust_username', '$cust_phone', '$cust_address', '$cust_email', '$cart_image', '$cart_material', '$cart_price', '$cart_name', '$size[$count]');";
						$result2 = mysqli_query($dbc, $query2);

						// get current quantity amount of product
						$query4 =  "SELECT * FROM product
									WHERE product.pd_image='". $cart_image ."'";
						$result4 = mysqli_query($dbc, $query4);

						while($roww = mysqli_fetch_array($result4)){
							$quantity = $roww['pd_quantity'];
						}

						$quantity = $quantity - 1;

						if($quantity > 0){

							// update quantity in product table
							$query5 =  "UPDATE product
										SET pd_quantity='". $quantity ."'
										WHERE product.pd_image='". $cart_image ."'";
							$result5 = mysqli_query($dbc, $query5);

						}else{

							// product out of stock. Delete row of product in product table
							$query6 =  "DELETE FROM product
										WHERE product.pd_image='". $cart_image ."'";
							$result6 = mysqli_query($dbc, $query6);

						}

					echo "</div>";
					$count++;
				}

				$query3 = "DELETE FROM cart;";
				$result3 = mysqli_query($dbc, $query3);

				echo "<p style='text-align:center;'><a href='index.php'><button class='btn btn-sm btn-primary'>Back to Home Page</button></a></p>";?>

				<?php echo "</div>";

			echo "</form>";

		}?>
		<div id="demoFont3">
		<form name="frm_customer_detail" action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="POST">
   							<input type='hidden'
							name='business' value='YOUR_BUSINESS_EMAIL'> <input
							type='hidden' name='item_name' value='Cart Item'> <input
							type='hidden' name='item_number' value="<?php echo $order;?>"> <input
							type='hidden' name='amount' value='<?php echo $item_price; ?>'> <input type='hidden'
							name='currency_code' value='USD'> <input type='hidden'
							name='notify_url'
							value='http://yourdomain.com/shopping-cart-check-out-flow-with-payment-integration/notify.php'> <input
							type='hidden' name='return'
							value='http://yourdomain.com/shopping-cart-check-out-flow-with-payment-integration/response.php'> <input type="hidden"
							name="cmd" value="_xclick">  <input
							type="hidden" name="order" value="<?php echo $order;?>">
    			<div>
        			<input type="submit" class='btn btn-sm btn-primary' align="middle" name="continue_payment" value="Continue Payment">
    			</div>
    			</form>
    		</div>
	<?php }else{
		echo "<p><b>You have to login first before submit your purchase order</b></p>";
		echo "<br>";
		echo "<a href='login'>Go to Login page</a>";
	}


?>

	<script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
</body>
