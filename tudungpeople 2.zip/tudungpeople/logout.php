<?php

	session_start();

	$page_title = 'Logout Page';

	require_once('connect.php');
	$query = "DELETE FROM cart;";
	$result = mysqli_query($dbc, $query);
?>

<html>

		<div id="demoFont">You have been Logged Out</div>
		<br>
		<br>
		<p align="center"><a href="index.php">Go back to Main Page</a></p>
	</body>

</html>
<?php


	// remove all session variables
	session_unset();



	// destroy the session
	session_destroy();
?>
