<?php

	// start the session
	session_start();

	$page_title = 'Login Page';

	if(isset($_POST['buttonLogin'])){

		if(isset($_SESSION['id'])){

			//echo 'Id: ' . $_SESSION['id'];
			$id = $_SESSION['id'];
			echo "<p align='center' style=' sans-serif; font-size:20px;'>You have already login. Please logout first if you intended on using another account</p>";

		}else{

			require 'connect.php';

			$username = $_POST['username'];
			$password = $_POST['password'];

			$result = mysqli_query($dbc, 'SELECT * FROM customer WHERE customer.cust_username="' . $username . '" and customer.cust_password=SHA("' . $password . '")');

			if(mysqli_num_rows($result) == 1){

				while($row = mysqli_fetch_array($result)){
					$id = $row['cust_id'];
				}

				// Set session variables
				$_SESSION['username'] = $username;
				$_SESSION['id'] = $id;
				header("location: index.php");

			}else{
				echo 'Invalid account';
			}
			mysqli_close($dbc);

		}

	}

?>


<!DOCTYPE html>
<html>

<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<header>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Mukta:300,400,700">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
		<nav>
		</nav>
	</header>

	<!--<section class="main-container">-->
		<div class="main-wrapper">
			<div class="site-blocks-cover" style="background-image: url(images/front.jpg);" data-aos="fade">
      <div class="container">
        <div class="row align-items-start align-items-md-center justify-content-end">
          <div class="col-md-5 text-center text-md-left pt-5 pt-md-0">
            <form style="text-align:center" action="login.php?action=login" method="post">

		<br>
		<p style=" sans-serif; font-size:30px;"><b>Login Into Your Account</b></p>

		<p style=" sans-serif; font-size:20px;"><b>Enter username and password to login</b></p>

		<p style=" sans-serif; font-size:20px;"><b>Click below to go to<br><a href="index.php" style="margin-top: 1px;">HOME</a></b></p>
		<br>

		<div class="box">

			<p style=" sans-serif; font-size:20px;"><b>USERNAME</b></p>
			<p><input type="text" name="username" style="padding: 10px 20px;"></p>

			<p style=" sans-serif; font-size:20px;"><b>PASSWORD</b></p>
			<p><input type="password" name="password" style="padding: 10px 20px;"></p>

			<p><input type="submit" class="buttonDesign" value="Login" name="buttonLogin"></p>

			<p style=" sans-serif; font-size:15px;">Click here to <a href="signup.php" style="margin-top: 1px;">SIGN UP</a> if you have not registered yet</a></p>

		</div>

	</form>
            </div>
          </div>
        </div>
      </div>
    </div>
		</div>
	<!--</section>-->

	  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
</body>
</html>
