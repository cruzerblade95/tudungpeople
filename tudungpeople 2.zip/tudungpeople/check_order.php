<?php 
  
  $page_title = 'Check Order Page';
  
  if(isset($_POST['delete'])){
    
    $orderid = $_POST['delete'];
    
    require_once 'connect.php';
      
    $query2 = "DELETE FROM orderform WHERE order_id=". $orderid ."";
    $result2 = mysqli_query($dbc, $query2);
    
  }
  
?>
<html lang="en">
  <head>
    <title>Admin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Mukta:300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    <style>
    
    #content{
      width: 50%;
      margin: 20px auto;
      border: 1px solid #cbcbcb;
      background-color: #cfd2ff;
    }
    
    #img_div{
      width: 80%;
      padding: 5px;
      margin: 15px auto;
      border: 1px solid #cbcbcb;
      background-color: #edeeff;
    }
    #img_div:after{
      content: "";
      display: block;
      clear: both;
    }
    #shoes_img{
      float: left;
      margin: 5px;
      width: 200px;
      height: 140px;
    }
    
    table, td, th {    
      border: 1px solid #ddd;
      text-align: left;
    }

    table {
      border-collapse: collapse;
      width: 100%;
    }

    th, td {
      padding: 15px;
    }
    
  </style>
  </head>
  <body>
  
  <div class="site-wrap">
    <header class="site-navbar" role="banner">
      <div class="site-navbar-top">
        <div class="container">
          <div class="row align-items-center">

            <div class="col-6 col-md-4 order-2 order-md-1 site-search-icon text-left">
              <form action="" class="site-block-top-search">
              </form>
            </div>

            <div class="col-12 mb-3 mb-md-0 col-md-4 order-1 order-md-2 text-center">
              <div class="site-logo">
                <a href="index.html" class="js-logo-clone">Tudung People</a>
              </div>
            </div>
   
            <div class="col-6 col-md-4 order-3 order-md-3 text-right">
              <div class="site-top-icons">
                <ul>
                  <li class="d-inline-block d-md-none ml-md-0"><a href="#" class="site-menu-toggle js-menu-toggle"><span class="icon-menu"></span></a></li>
                </ul>
              </div> 
            </div>

          </div>
        </div>
      </div> 
      <nav class="site-navigation text-right text-md-center" role="navigation">
        <div class="container">
          <ul class="site-menu js-clone-nav d-none d-md-block">
           <!-- <li class="has-children active"> -->
             <li><a href="view_users.php">View Registered Users</a></li>
             <!-- <ul class="dropdown">
                <li><a href="#">Menu One</a></li>
                <li><a href="#">Menu Two</a></li>
                <li><a href="#">Menu Three</a></li>
                <li class="has-children">
                  <a href="#">Sub Menu</a>
                  <ul class="dropdown">
                    <li><a href="#">Menu One</a></li>
                    <li><a href="#">Menu Two</a></li>
                    <li><a href="#">Menu Three</a></li>
                  </ul>
                </li> 
              </ul> 
            </li> -->
            <!--<li class="has-children"> -->
            <li><a href="all_products.php">All Products</a></li>
             <!-- <ul class="dropdown">
                <li><a href="#">Menu One</a></li>
                <li><a href="#">Menu Two</a></li>
                <li><a href="#">Menu Three</a></li>
              </ul>
            </li> -->
           
            <li><a href="check_order.php">Check Order</a></li>
            <li><a href="add_stock.php">Add Stock</a></li>
            <li><a href="admin.php">Log Out</a></li>
          </ul>
        </div>
      </nav>
    </header>

    <div class="site-section border-bottom" data-aos="fade">
      <div class="container">
              <figure>
  <p style=" sans-serif; font-size:30px;" align="center"><b>PRODUCT ORDER LIST</b></p>
  <p style=" sans-serif; font-size:20px;" align="center">
  <b>This page produces the list of order requested by all customers</b></p>
  <?php
      
      require_once 'connect.php';
      
      $query = "SELECT * FROM orderform";
      $result = mysqli_query($dbc, $query);
      $count = mysqli_num_rows($result);
      
      if ($count > 0) {
        
        echo "<p style=' sans-serif; font-size:20px;' align='center'>There are currently $count orders from customers.</p>\n";
        
        echo "<form action='check_order.php' method='post' enctype='multipart/form-data'>";
        
        //echo "<div id='content'>";
        
        echo "<table>
          <tr>
          <th>No.</th>
          <th>Cust Name</th>
          <th>Cust Username</th>
          <th>Cust Phone</th>
          <th>Cust Email</th>
          <th>Cust Address</th>
          <th>Material</th>
          <th>Price</th>
          <th>Name</th>
          <th>Size</th>
          <th>Delete</th>
          </tr>";
          
        
        while($row = mysqli_fetch_array($result)){
          
          $fname = $row['cust_fname'];
          $lname = $row['cust_lname'];
          $username = $row['cust_username'];
          $phone = $row['cust_phone'];
          $email = $row['cust_email'];
          $address = $row['cust_address'];
          $c_material = $row['cart_material'];
          $c_price = $row['cart_price'];
          $c_name = $row['cart_name'];
          $c_size = $row['cart_size'];
          
          echo "<tr>";
          echo "<td>" . $count . "</td>";
          echo "<td>" . $fname . " ". $lname ."</td>";
          echo "<td>" . $username . "</td>";
          echo "<td>" . $phone . "</td>";
          echo "<td>" . $email . "</td>";
          echo "<td>" . $address . "</td>";
          echo "<td>" . $c_material . "</td>";
          echo "<td>" . $c_price . "</td>";
          echo "<td>" . $c_name . "</td>";
          echo "<td>" . $c_size . "</td>";
          echo "<td><button type='submit' formaction='check_order.php' name='delete' value=" . $row['order_id'] . ">Delete</button></td>";
          echo "</tr>";
          ++$count;
          
        }
        echo "</table>";
        /*
        while($row = mysqli_fetch_assoc($result)){
          
          //echo "<div id='img_div'>";
            echo "<img id='shoes_img' name='pd_image' src='shoes/" . $row['cart_image'] . "'>";
            echo "<p>" . $row['cart_brand'] . "</p>";
            echo "<p>RM " . $row['cart_price'] . "</p>";
            echo "<p>" . $row['cart_name'] . "</p>";
            echo "<select name='cart_size[]'>
                <option value='UK 5'>UK 5</option>
                <option value='UK 6'>UK 6</option>
                <option value='UK 7'>UK 7</option>
                <option value='UK 8'>UK 8</option>
                <option value='UK 9'>UK 9</option>
              </select>";
              
            echo "<p><button type='submit' formaction='cart.php' name='cancel' value=" . $row['cart_id'] . ">Cancel</button></p>";
            
          //echo "</div>";
          
        }
        */
        //echo "</div>";
        
        
      echo "</form>";
      
      mysqli_close($dbc);
    }
    else { // If it did not run OK.
          echo "<p style='color:#020f85; font-family:Arial Narrow, sans-serif; font-size:20px;' align='center'>There are currently no orders from customers retrieved</p></font>";
        }
    ?>
        </div>
      </div>

    <!--<div class="site-section site-section-sm site-blocks-1">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="">
            <div class="icon mr-4 align-self-start">
              <span class="icon-truck"></span>
            </div>
            <div class="text">
              <h2 class="text-uppercase">Free Shipping</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus at iaculis quam. Integer accumsan tincidunt fringilla.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="100">
            <div class="icon mr-4 align-self-start">
              <span class="icon-refresh2"></span>
            </div>
            <div class="text">
              <h2 class="text-uppercase">Free Returns</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus at iaculis quam. Integer accumsan tincidunt fringilla.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="200">
            <div class="icon mr-4 align-self-start">
              <span class="icon-help"></span>
            </div>
            <div class="text">
              <h2 class="text-uppercase">Customer Support</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus at iaculis quam. Integer accumsan tincidunt fringilla.</p>
            </div>
          </div>
        </div>
      </div>
    </div>-->


    <!--<div class="site-section block-3 site-blocks-2 bg-light">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 site-section-heading text-center pt-4">
            <h2>Featured Products</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="nonloop-block-3 owl-carousel">
              <div class="item">
                <div class="block-4 text-center">
                  <figure class="block-4-image">
                    <img src="images/cloth_1.jpg" alt="Image placeholder" class="img-fluid">
                  </figure>
                  <div class="block-4-text p-4">
                    <h3><a href="#">Tank Top</a></h3>
                    <p class="mb-0">Finding perfect t-shirt</p>
                    <p class="text-primary font-weight-bold">$50</p>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="block-4 text-center">
                  <figure class="block-4-image">
                    <img src="images/cloth_2.jpg" alt="Image placeholder" class="img-fluid">
                  </figure>
                  <div class="block-4-text p-4">
                    <h3><a href="#">Polo Shirt</a></h3>
                    <p class="mb-0">Finding perfect products</p>
                    <p class="text-primary font-weight-bold">$50</p>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="block-4 text-center">
                  <figure class="block-4-image">
                    <img src="images/cloth_3.jpg" alt="Image placeholder" class="img-fluid">
                  </figure>
                  <div class="block-4-text p-4">
                    <h3><a href="#">T-Shirt Mockup</a></h3>
                    <p class="mb-0">Finding perfect products</p>
                    <p class="text-primary font-weight-bold">$50</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>-->

    <!--<div class="site-section block-8">
      <div class="container">
        <div class="row justify-content-center  mb-5">
          <div class="col-md-7 site-section-heading text-center pt-4">
            <h2>Big Sale!</h2>
          </div>
        </div>
        <div class="row align-items-center">
          <div class="col-md-12 col-lg-7 mb-5">
            <a href="#"><img src="images/blog_1.jpg" alt="Image placeholder" class="img-fluid rounded"></a>
          </div>
          <div class="col-md-12 col-lg-5 text-center pl-md-5">
            <h2><a href="#">Big Discount When Buy In Bundle</a></h2>
            <p class="post-meta mb-4">By <a href="#">Harith Afiq</a> <span class="block-8-sep">&bullet;</span> September 3, 2018</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam iste dolor accusantium facere corporis ipsum animi deleniti fugiat. Ex, veniam?</p>
            <p><a href="#" class="btn btn-primary btn-sm">Order Now</a></p>
          </div>
        </div>
      </div>
    </div>-->

    <!--<footer class="site-footer border-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mb-5 mb-lg-0">
            <div class="row">
              <div class="col-md-12">
                <h3 class="footer-heading mb-4">Navigations</h3>
              </div>
              <div class="col-md-6 col-lg-4">
                <ul class="list-unstyled">
                  <li><a href="#">Sell online</a></li>
                  <li><a href="#">Features</a></li>
                  <li><a href="#">Shopping cart</a></li>
                  <li><a href="#">Store builder</a></li>
                </ul>
              </div>
              <div class="col-md-6 col-lg-4">
                <ul class="list-unstyled">
                  <li><a href="#">Mobile commerce</a></li>
                  <li><a href="#">Dropshipping</a></li>
                  <li><a href="#">Website development</a></li>
                </ul>
              </div>
              <div class="col-md-6 col-lg-4">
                <ul class="list-unstyled">
                  <li><a href="#">Point of sale</a></li>
                  <li><a href="#">Hardware</a></li>
                  <li><a href="#">Software</a></li>
                </ul>
              </div> 
            </div> 
          </div> 
          <div class="col-md-6 col-lg-3 mb-4 mb-lg-0">
            <h3 class="footer-heading mb-4">Promo</h3>
            <a href="#" class="block-6">
              <img src="images/hero_1.jpg" alt="Image placeholder" class="img-fluid rounded mb-4">
              <h3 class="font-weight-light  mb-0">Finding Your Perfect Shirt</h3>
              <p>Promo from  nuary 15 &mdash; 25, 2019</p>
            </a>
          </div> 
          <div class="col-md-6 col-lg-3">
            <div class="block-5 mb-5">
              <h3 class="footer-heading mb-4">Contact Info</h3>
              <ul class="list-unstyled">
                <li class="address">Lot 4, 4th Floor, Jalan 3/4, Bangunan Mentari Indah Belaka, Singapore</li>
                <li class="phone"><a href="tel://23923929210">+6019 999 999</a></li>
                <li class="email">DontEmailMe@PrintThis.com</li>
              </ul>
            </div>

            <div class="block-7">
              <form action="#" method="post">
                <label for="email_subscribe" class="footer-heading">Subscribe</label>
                <div class="form-group">
                  <input type="text" class="form-control py-4" id="email_subscribe" placeholder="Email">
                  <input type="submit" class="btn btn-sm btn-primary" value="Send">
                </div>
              </form>
            </div>
          </div>
        </div>-->
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> <!-- All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" class="text-primary">Colorlib</a>
             Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
          
        </div>
      </div>
    </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
    
  </body>
</html>