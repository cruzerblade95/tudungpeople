<?php 

	
	$page_title = 'Sign Up Page';
	
	if(isset($_POST['submitted'])){
		
	
			// "require_once" check if the file has already been included, and if so, not include (require) it again
			require_once('connect.php');
			
			// declare the array of errors
			$errors = array();
			
			// validate the form
			if(empty($_POST['fname'])){
				$errors[] = 'You forgot to enter your first name';
			}else{
				$fname = $_POST['fname'];
			}
			
			if(empty($_POST['lname'])){
				$errors[] = 'You forgot to enter your last name';
			}else{
				$lname = $_POST['lname'];
			}
			
			if(empty($_POST['username'])){
				$errors[] = 'You forgot to enter your username';
			}else{
				$username = $_POST['username'];
			}
			
			if(empty($_POST['password'])){
				$errors[] = 'You forgot to enter your password';
			}else{
				$password = $_POST['password'];
			}
			
			if(empty($_POST['phone'])){
				$errors[] = 'You forgot to enter your phone number';
			}else{
				$phone = $_POST['phone'];
			}
			
			if(empty($_POST['address'])){
				$errors[] = 'You forgot to enter your address';
			}else{
				$address = $_POST['address'];
			}
			
			if(empty($_POST['email'])){
				$errors[] = 'You forgot to enter your email';
			}else{
				$email = $_POST['email'];
			}
			
			$gender = $_POST['radioGender'];
			
			// if no error occured
			if(empty($errors)){
				
				$query = "SELECT cust_id FROM customer WHERE cust_email='$email'";
				// "mysqli_query" performs a query against the database.
				$result = mysqli_query($dbc, $query);
				
					// "mysqli_num_rows" returns the number of rows in a result set
				if(mysqli_num_rows($result) == 0){
					
					$query = "INSERT INTO customer (cust_fname, cust_lname, cust_username, cust_password, cust_phone, cust_email, cust_address, cust_gender, registration_date)
								VALUES('$fname', '$lname', '$username', SHA('$password'), '$phone', '$email', '$address', '$gender', NOW())";
					$result = mysqli_query($dbc, $query);
					echo '<br><p align="center" style=" sans-serif; font-size:20px;">Successfully Created Account. Please Login to continue</p>';
					
					
				}else{
					echo '<h2>Error!</h2>
							<p id="error">This account has already registered in the database</p>';
				}
				
			}else{
				
				echo '<h2>Error!</h2>
						<p id="error">The following error(s) occured:<br/></p>';
				foreach($errors as $msg){
					echo " - $msg<br/>";
				}
				echo '<p><b>Please fill in your information again</b></p>';
				
			}
			// "mysqli_close" closes a previously opened database connection
			mysqli_close($dbc);
			
	}

?>

<!DOCTYPE html>
<html>

<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">

	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Mukta:300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
</head>

<body>
	<header>
	</header>
	
	<section class="main-container">
		<div class="main-wrapper">
			<h2>Signup</h2>
			<form style="text-align:center" action="signup.php" method="post">

		<br>
		<p style=" sans-serif; font-size:30px;"><b>Create a New Account</b></p>
		<b>Already have one? </b><a href="login.php">Sign in here</a></p>
		<br>
		<br>
		
		<div class="box">
			
			<p style=" sans-serif; font-size:20px;"><b>FIRST NAME: </b><input type="text" name="fname" style="padding: 10px 20px;"></p>
			
			<p style=" sans-serif; font-size:20px;"><b>LAST NAME: </b><input type="text" name="lname" style="padding: 10px 20px;"></p>
			
			<p style=" sans-serif; font-size:20px;"><b>USERNAME: </b><input type="text" name="username" style="padding: 10px 20px;"></p>
			
			<p style=" sans-serif; font-size:20px;"><b>PASSWORD: </b><input type="password" name="password" style="padding: 10px 20px;"></p>
			
			<p style=" sans-serif; font-size:20px;"><b>&emsp;&emsp;PHONE: </b><input type="text" name="phone" style="padding: 10px 20px;"></p>
			
			<p style=" sans-serif; font-size:20px;"><b>&emsp;ADDRESS: </b><input type="text" name="address" style="padding: 10px 20px;"></p>
			
			<p style=" sans-serif; font-size:20px;"><b>&emsp;&emsp; EMAIL: </b><input type="text" name="email" style="padding: 10px 20px;"></p>
			
			<label class="container" style=" sans-serif; font-size:20px; margin-right:15px;"><b>&emsp;MALE</b>
			  <input type="radio" checked="checked" name="radioGender" value="male">
			  <span class="checkmark"></span>
			</label>
			
			<label class="container" style=" sans-serif; font-size:20px; margin-right:35px;"><b>&emsp;&emsp;&emsp;FEMALE</b>
			  <input type="radio" name="radioGender" value="female">
			  <span class="checkmark"></span>
			</label>
			
			<p><input type="submit" class="buttonDesign" name="submit" value="Sign Up"></p>
			<input type="hidden" name="submitted" value="TRUE">
			
		</div>
		
	</form>

		</div>
	</section>

</body>
</html>